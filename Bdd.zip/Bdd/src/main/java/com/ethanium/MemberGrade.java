package com.ethanium;

public enum MemberGrade {

    Bronze, Silver, Gold;

}