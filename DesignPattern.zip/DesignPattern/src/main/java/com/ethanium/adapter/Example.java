package com.ethanium.adapter;

public class Example {

    public static void main(String[] args) {

        MediaPlayer player = new MP4();
        player.play("music.mp4");

        MediaPlayer player1 = new MediaFormatAdapter(new VLC());
        player1.play("movie.avi");


    }
}
