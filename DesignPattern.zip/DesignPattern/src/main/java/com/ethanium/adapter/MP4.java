package com.ethanium.adapter;

public class MP4 implements MediaPlayer {

    @Override
    public void play(String filename) {
        System.out.println("Playing Mp4 with filename: "+filename);
    }
}
