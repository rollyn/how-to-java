package com.ethanium.adapter;

public class MediaFormatAdapter implements MediaPlayer {

    private MediaPackage media;

    public MediaFormatAdapter(MediaPackage media) {
        this.media = media;
    }

    @Override
    public void play(String filename) {
        System.out.println("Using Adapter");
        media.playFile(filename);
    }
}
