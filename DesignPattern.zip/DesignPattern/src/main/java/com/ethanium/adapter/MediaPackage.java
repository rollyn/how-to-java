package com.ethanium.adapter;

public interface MediaPackage {

    void playFile(String filename);
}
