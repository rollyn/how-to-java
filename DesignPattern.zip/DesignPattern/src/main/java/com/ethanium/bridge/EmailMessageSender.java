package com.ethanium.bridge;

public class EmailMessageSender implements MessageSender {

    @Override
    public void sendMessage() {
        System.out.println("Sending Email...");
    }
}
