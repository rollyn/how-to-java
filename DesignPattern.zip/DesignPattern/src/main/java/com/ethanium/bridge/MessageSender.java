package com.ethanium.bridge;

public interface MessageSender {
    void sendMessage();
}
