package com.ethanium.bridge;

public class TextMeesageSender implements MessageSender {
    @Override
    public void sendMessage() {
        System.out.println("Sending Text Message..");
    }
}
