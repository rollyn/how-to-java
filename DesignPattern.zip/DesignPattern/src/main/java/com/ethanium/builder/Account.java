package com.ethanium.builder;

public class Account {

    private String accountID;
    private String name;
    private Double balance;

    public Account() {}

    public Account(String accountID, String name, Double balance) {
        this.accountID = accountID;
        this.name = name;
        this.balance = balance;
    }

    public String getAccountID() {
        return accountID;
    }

    public void setAccountID(String accountID) {
        this.accountID = accountID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getBalance() {
        return balance;
    }

    public void setBalance(Double balance) {
        this.balance = balance;
    }
}
