package com.ethanium.builder;

public class BankAccount {

    private String accountID;
    private String name;
    private Double balance;

    public static class Builder {

        private String accountID;
        private String name;
        private Double balance;

        public Builder withAccountID(String accountID) {
            this.accountID = accountID;
            return this;
        }

        public Builder withName(String name) {
            this.name = name;
            return this;
        }

        public Builder withMoney(Double balance) {
            this.balance = balance;
            return this;
        }

        public BankAccount build() {
            return new BankAccount(accountID, name, balance);
        }
    }

    private BankAccount(String accountID, String name, Double balance) {
        this.accountID = accountID;
        this.name = name;
        this.balance = balance;
    }

}