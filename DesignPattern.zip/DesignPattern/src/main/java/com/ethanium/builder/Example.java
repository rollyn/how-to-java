package com.ethanium.builder;

public class Example {

    public static void main(String[] args) {
        String[] names = {"John","James","Peter"};

        StringBuilder builder = new StringBuilder();
        for(String name: names) {
            builder.append(name);
        }
        System.out.println( builder.toString() );
    }
}
