package com.ethanium.builder;

public class Example2 {

    public static void main(String[] args) {

        Account account1 = new Account();
        account1.setAccountID("001");
        account1.setName("JAMES");
        account1.setBalance(200d);

        Account account2 = new Account("001","ETHAN",100d);




        BankAccount bankAccount = new BankAccount.Builder()
                .withAccountID("001")
                .withName("JOHN")
                .withMoney(200d)
                .build();


    }
}
