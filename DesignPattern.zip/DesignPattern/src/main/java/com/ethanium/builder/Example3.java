package com.ethanium.builder;

public class Example3 {

    public static void main(String[] args) {
        SchoolAccount account = SchoolAccount.builder()
                .accountID("001")
                .balance(100d)
                .name("PETER").build();
//        SchoolAccount account = new SchoolAccount("001","JOHN",100d);


    }
}
