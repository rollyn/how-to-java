package com.ethanium.builder;

import lombok.Builder;

@Builder
//@AllArgsConstructor
public class SchoolAccount {

    private String accountID;
    private String name;
    private Double balance;

}
