package com.ethanium.chain;

public class Dev extends SmsBroadcast {

    public Dev(int importance) {
        this.importance = importance;
    }

    protected void sendSms(String message) {
        System.out.print("An Sms message was sent to the DEV. The message was: ");
        System.out.println(message);
    }
}