package com.ethanium.chain;

public class Example {

    public static void main(String[] args) {

        SmsBroadcast first = new Dev(2);
        SmsBroadcast second = new TeamLead(1);
        SmsBroadcast third = new ProjectManager(0);

        first.setNext(second);
        second.setNext(third);

        first.trySendingSms(2, "This is a HIGH priority message.");
        System.out.println("-----------------------------------------------------");

//        first.trySendingSms(1, "This is a MEDIUM priority message.");
//        System.out.println("-----------------------------------------------------");
//
//        third.trySendingSms(1, "This is a HIGH priority message.");
//        System.out.println("-----------------------------------------------------");
    }
}
