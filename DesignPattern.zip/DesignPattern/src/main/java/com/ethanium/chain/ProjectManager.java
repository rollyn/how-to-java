package com.ethanium.chain;

public class ProjectManager extends SmsBroadcast {

    public ProjectManager(int importance) {
        this.importance = importance;
    }

    protected void sendSms(String message) {
        System.out.print("An Sms message was sent to the PROJECT MANAGER. The message was: ");
        System.out.println(message);
    }
}
