package com.ethanium.chain;

public abstract class SmsBroadcast {

        protected int importance;

        //next element in the Chain of Responsibility
        protected SmsBroadcast next;

        public void setNext(SmsBroadcast next){
            this.next = next;
        }

        public void trySendingSms(int importance, String message){

            if (this.importance >= importance) {
                sendSms(message);
            }
            if(next !=null){
                next.trySendingSms(importance, message);
            }
        }

        abstract protected void sendSms(String message);
}
