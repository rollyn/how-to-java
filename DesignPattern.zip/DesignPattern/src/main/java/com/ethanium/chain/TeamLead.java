package com.ethanium.chain;

public class TeamLead extends SmsBroadcast {

    public TeamLead(int importance) {
        this.importance = importance;
    }

    protected void sendSms(String message) {
        System.out.print("An Sms message was sent to the TEAM LEAD. The message was: ");
        System.out.println(message);
    }
}