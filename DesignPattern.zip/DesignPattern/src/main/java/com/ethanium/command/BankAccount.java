package com.ethanium.command;

public class BankAccount implements TransactionAccount {

    private double balance;

    public BankAccount(double amount) {
        this.balance = amount;
    }

    @Override
    public void deposit(double amount) {
        this.balance += amount;
    }

    @Override
    public void withdraw(double amount) {
        if (this.balance - amount < 0) {
            System.out.println("Overdraft");
        } else {
            this.balance -= amount;
        }
    }

    @Override
    public String toString() {
        return "BankAccount{" +
                "balance=" + balance +
                '}';
    }
}
