package com.ethanium.command;

public class BankAccountCommand implements Command {

    protected enum Action {
        DEPOSIT,
        WITHDRAW
    }

    private BankAccount account;
    private Action action;
    private double amount;


    @Override
    public void call() {
        switch (action) {
            case DEPOSIT:
                    account.deposit(amount);
                    break;
            case WITHDRAW:
                    account.withdraw(amount);
                    break;
        }
    }

    public BankAccountCommand(BankAccount account, Action action, double amount) {
        this.account = account;
        this.action = action;
        this.amount = amount;
    }

    @Override
    public String toString() {
        return "BankAccountCommand{" +
                "account=" + account +
                ", action=" + action +
                ", amount=" + amount +
                '}';
    }
}
