package com.ethanium.command;

public interface Command {

    void call();
}
