package com.ethanium.command;

import java.util.List;

import static com.ethanium.command.BankAccountCommand.Action.DEPOSIT;
import static com.ethanium.command.BankAccountCommand.Action.WITHDRAW;

public class Example {

    public static void main(String[] args) {
        BankAccount account = new BankAccount(0d);

        List<BankAccountCommand> commands = List.of(
            new BankAccountCommand(account, DEPOSIT, 100),
            new BankAccountCommand(account, DEPOSIT, 200),
            new BankAccountCommand(account, WITHDRAW, 100)
        );

        commands.forEach(c -> {
            c.call();
            System.out.println( c );
        });
    }
}
