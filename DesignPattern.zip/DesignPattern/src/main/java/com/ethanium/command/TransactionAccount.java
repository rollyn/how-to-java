package com.ethanium.command;

public interface TransactionAccount {

    void deposit(double amount);
    void withdraw(double amount);

}
