package com.ethanium.composite;

import java.util.ArrayList;
import java.util.List;

public class Employee {

    private String employeeID;
    private String name;
    private String position;
    private List<Employee> subordinates;

    public Employee(String employeeID, String name, String position) {
        this.employeeID = employeeID;
        this.name = name;
        this.position = position;
        subordinates = new ArrayList<>();
    }

    public void add(Employee e) {
        subordinates.add(e);
    }

    public void remove(Employee e) {
        subordinates.remove(e);
    }

    public List<Employee> getSubordinates(){
        return subordinates;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "employeeID='" + employeeID + '\'' +
                ", name='" + name + '\'' +
                ", position='" + position + '\'' +
                ",\n subordinates=" + subordinates +
                "}\n";
    }
}
