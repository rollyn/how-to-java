package com.ethanium.composite;

public class Example {

    public static void main(String[] args) {

        Employee CEO = new Employee("001","JOHN", "CEO");

        Employee headIT = new Employee("002","JAMES", "IT");
        Employee headHR = new Employee("003","JANE", "HR");

        Employee devIT  = new Employee("004","PETER", "DEV");
        Employee supportIT  = new Employee("005","MATTHEW", "SUPPORT");

        Employee assistantHR = new Employee("006","KATHY", "Assistant");

        CEO.add(headHR);
        CEO.add(headIT);

        headHR.add(assistantHR);

        headIT.add(devIT);
        headIT.add(supportIT);

        System.out.println( CEO );


    }
}
