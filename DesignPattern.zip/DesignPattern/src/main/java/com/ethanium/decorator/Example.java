package com.ethanium.decorator;

public class Example {

    public static void main(String[] args) {

        String employees = "Name,Position\nJohn Smith,100\nSteven Jobs,200";

        DataSourceDecorator encoded = new CompressionDecorator(
                new EncryptionDecorator(
                        new FileDataSource("employee.txt")));
        encoded.writeData(employees);
        DataSource plain = new FileDataSource("employee.txt");

        System.out.println("- Input ----------------");
        System.out.println(employees);
        System.out.println("- Encoded --------------");
        System.out.println(plain.readData());
        System.out.println("- Decoded --------------");
        System.out.println(encoded.readData());
    }
}
