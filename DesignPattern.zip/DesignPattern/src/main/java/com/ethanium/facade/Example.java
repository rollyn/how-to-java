package com.ethanium.facade;

public class Example {

    public static void main(String[] args) {

      FormGeneratorFacade.generateForm(FormType.HTML,"c:/datapath");

      FormGeneratorFacade.generateForm(FormType.PDF,"c:/datapath");
    }
}
