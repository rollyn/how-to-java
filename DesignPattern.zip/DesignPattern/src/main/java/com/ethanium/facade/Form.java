package com.ethanium.facade;

public class Form {

    private FormHeader header;
    private FormBody body;
    private FormFooter footer;

    public FormHeader getHeader() {
        return header;
    }

    public void setHeader(FormHeader header) {
        this.header = header;
    }

    public FormBody getBody() {
        return body;
    }

    public void setBody(FormBody body) {
        this.body = body;
    }

    public FormFooter getFooter() {
        return footer;
    }

    public void setFooter(FormFooter footer) {
        this.footer = footer;
    }
}
