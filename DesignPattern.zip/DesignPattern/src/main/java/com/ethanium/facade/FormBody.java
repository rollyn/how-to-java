package com.ethanium.facade;

public class FormBody {
}
