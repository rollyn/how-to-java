package com.ethanium.facade;

public class FormFooter {
}
