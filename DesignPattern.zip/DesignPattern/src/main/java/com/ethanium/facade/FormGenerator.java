package com.ethanium.facade;

public class FormGenerator {

    public void writeHTMLForm(Form form, String location) {
        System.out.println("HTML Form written");
        //implementation
    }

    public void writePDFForm(Form form, String location) {
        System.out.println("Pdf Form written");
        //implementation
    }
}
