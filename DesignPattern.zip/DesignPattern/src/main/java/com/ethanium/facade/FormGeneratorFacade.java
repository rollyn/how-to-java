package com.ethanium.facade;

public class FormGeneratorFacade {

    public static void generateForm(FormType type, String location)
    {
        Form form = new Form();
        form.setHeader(new FormHeader());
        form.setFooter(new FormFooter());

        //Get data from somewhere
        form.setBody(new FormBody());

        //Generate the form
        FormGenerator generator = new FormGenerator();
        switch(type) {
            case HTML:
                generator.writeHTMLForm(form, location);
                break;
            case PDF:
                generator.writePDFForm(form, location);
                break;
        }
    }
}
