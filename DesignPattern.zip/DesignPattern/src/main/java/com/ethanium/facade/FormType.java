package com.ethanium.facade;

public enum FormType {
    PDF,
    HTML
}
