package com.ethanium.factory;

public interface Animal {

    void speak();
}
