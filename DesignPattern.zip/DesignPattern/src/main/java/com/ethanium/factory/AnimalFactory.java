package com.ethanium.factory;

public class AnimalFactory {

    public static Animal create(String type) {
        if (type.equals("Dog")) {
            return new Dog();
        } else if (type.equals("Duck")) {
            return new Duck();
        }
        return null;
    }
}
