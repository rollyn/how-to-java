package com.ethanium.factory;

public class Example {

    public static void main(String[] args) {

        Animal animal = AnimalFactory.create("Dog");
        animal.speak();

        Animal anotherAnimal = AnimalFactory.create("Duck");
        anotherAnimal.speak();

    }
}
