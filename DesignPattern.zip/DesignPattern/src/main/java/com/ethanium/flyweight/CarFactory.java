package com.ethanium.flyweight;

import java.util.HashMap;
import java.util.Map;

public class CarFactory {

    private static Map<String, RaceCar> flyweights = new HashMap<>();

    public static RaceCar getRaceCar(String key) {
        if (flyweights.containsKey(key)) {
            return flyweights.get(key);
        }
        RaceCar raceCar;
        switch (key) {
            case "Ferrari":
                raceCar = new FerrariCar();
                raceCar.name = "Ferrari";
                raceCar.speed = 140;
                raceCar.horsePower = 400;
                break;
            case "Porsche":
                raceCar = new PorscheCar();
                raceCar.name = "Porsche";
                raceCar.speed = 160;
                raceCar.horsePower = 1000;
                break;
            default:
                throw new IllegalArgumentException("Unsupported car type.");
        }
        flyweights.put(key, raceCar);
        return raceCar;
    }
}
