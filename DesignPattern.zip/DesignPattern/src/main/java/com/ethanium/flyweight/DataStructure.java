package com.ethanium.flyweight;

import java.util.*;

public class DataStructure {

    public static void main(String[] args) {
        List l = new LinkedList();
        l.add("a");
        l.add("b");
        l.add("c");


        Set s = new HashSet<>();

        Map<String, String> m = new HashMap<>();

        m.put("PH","Philippines");
        m.put("SG","Singapore");

        System.out.println(  m.get("SG") );

        // dictionary
        // tuple

    }
}
