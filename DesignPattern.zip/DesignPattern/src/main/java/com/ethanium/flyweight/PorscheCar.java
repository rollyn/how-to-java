package com.ethanium.flyweight;

public class PorscheCar extends RaceCar {

    public static int num;
    public PorscheCar() {
        num++;
    }

    @Override
    void moveCar(int currentX, int currentY, int newX, int newY) {
        System.out.println("New location of "+this.name+" is X: "+newX + " - Y: "+newY);
    }
}
