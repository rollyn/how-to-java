package com.ethanium.interpreter;

public interface Element {
    int eval();
}
