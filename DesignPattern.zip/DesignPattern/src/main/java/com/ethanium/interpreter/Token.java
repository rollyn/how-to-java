package com.ethanium.interpreter;

public class Token {

    public enum Type {
        INTEGER,
        PLUS,
        MINUS,
        LPAREN,
        RPAREN
    }

    public Type type;
    public String expression;

    public Token(Type type, String expression) {
        this.type = type;
        this.expression = expression;
    }

    @Override
    public String toString() {
        return "Token{" +
                "type=" + type +
                ", expression='" + expression + '\'' +
                '}';
    }
}
