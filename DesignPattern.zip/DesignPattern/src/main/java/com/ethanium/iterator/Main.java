package com.ethanium.iterator;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        List<String> names = Arrays.asList("John","James","Peter");

//        for(int i=0;i<names.size();i++) {
//            System.out.println( names.get(i) );
//        }
        Iterator<String> a = names.iterator();
        // peek

        while(a.hasNext()) {
            System.out.println( a.next() );
        }


    }
}
