package com.ethanium.memento;

class Memento {

  public int balance;

  public Memento(int balance) {
    this.balance = balance;
  }

}