package com.ethanium.nullobject;

public class Example {

    public static void main(String[] args) {
//        ConsoleLog log = new ConsoleLog();
        NullLog log = new NullLog();

        BankAccount ba = new BankAccount(log);
        ba.deposit(100);
        ba.withdraw(200);
    }
}
