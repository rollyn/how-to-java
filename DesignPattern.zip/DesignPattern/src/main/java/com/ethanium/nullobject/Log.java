package com.ethanium.nullobject;

public interface Log {
  void info(String msg);
  void warn(String msg);
}
