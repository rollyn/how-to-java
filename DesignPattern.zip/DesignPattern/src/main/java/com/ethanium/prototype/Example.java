package com.ethanium.prototype;

public class Example {

    public static void main(String[] args) {

        Person john = new Person("JOHN","SMITH",20,177, 90);

        //.1 using cloneable
       // Person jane = john;
        //jane.setFirstName("JANE");

       // System.out.println( john );
       // System.out.println( jane );

        // 2. copy constructor
        Person joe = new Person(john);
        joe.setFirstName("JOE");
        System.out.println( john );
        System.out.println( joe );
    }
}
