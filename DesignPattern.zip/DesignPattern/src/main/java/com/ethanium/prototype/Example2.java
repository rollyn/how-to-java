package com.ethanium.prototype;

import org.apache.commons.lang3.SerializationUtils;

import java.time.LocalDateTime;

public class Example2 {

    public static void main(String[] args) {

        Product product = new Product("001","Toothpaste", LocalDateTime.now());

        Product product1 = SerializationUtils.roundtrip(product);
        product1.setExpiryDate(LocalDateTime.now().plusDays(10));

        System.out.println( product );
        System.out.println( product1 );
    }
}
