package com.ethanium.prototype;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.ToString;

@Data
@AllArgsConstructor
@ToString
public class Person  implements Cloneable {
    private String firstName;
    private String lastName;
    private int age;
    private double height;
    private double weight;

    public Person(Person p) {
        this.firstName = p.getFirstName();
        this.lastName = p.getLastName();
        this.age = p.getAge();
        this.height = p.getHeight();
        this.weight = p.getWeight();
    }
}
