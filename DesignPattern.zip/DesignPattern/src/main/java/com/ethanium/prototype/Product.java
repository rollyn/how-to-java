package com.ethanium.prototype;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.ToString;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@ToString
@AllArgsConstructor
public class Product implements Serializable {

    private String productID;
    private String name;
    private LocalDateTime expiryDate;

}
