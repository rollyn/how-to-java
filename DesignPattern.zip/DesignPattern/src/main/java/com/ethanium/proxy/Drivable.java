package com.ethanium.proxy;

public interface Drivable {
    void drive();
}
