package com.ethanium.proxy;

public class Driver {
    protected int age;

    public Driver(int age) {
        this.age = age;
    }


}
