package com.ethanium.proxy;

public class Example {

    public static void main(String[] args) {
        Car car = new CarProxy(new Driver(16));
//        Car car = new Car(new Driver(10));
        car.drive();
    }
}
