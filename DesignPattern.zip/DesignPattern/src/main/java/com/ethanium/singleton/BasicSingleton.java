package com.ethanium.singleton;

import java.io.Serializable;

public class BasicSingleton implements Serializable  {

    private BasicSingleton() {

    }

    private static final BasicSingleton INSTANCE = new BasicSingleton();

    public static BasicSingleton getInstance() {
        return INSTANCE;
    }

    private int counter = 0;

    public int getCounter() {
        return counter;
    }

    public void setCounter(int counter) {
        this.counter = counter;
    }

//    protected Object readResolve() {
//        return INSTANCE;
//    }
}
