package com.ethanium.singleton;

public class Example {

    public static void main(String[] args) {

        NonSingleton nonSingleton = new NonSingleton();
        nonSingleton.setCounter(1);
        System.out.println( nonSingleton.getCounter() );

        NonSingleton nonSingleton1 = new NonSingleton();
        nonSingleton1.setCounter(2);
        System.out.println( nonSingleton1.getCounter() );



    }
}
