package com.ethanium.singleton;

public class Example2 {

    public static void main(String[] args) {

        BasicSingleton singleton = BasicSingleton.getInstance();
        singleton.setCounter(5);
        System.out.println( singleton.getCounter() );

        BasicSingleton singleton1 = BasicSingleton.getInstance();
        System.out.println( singleton1.getCounter() );

    }
}
