package com.ethanium.singleton;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Example3 {

    public static void main(String[] args) throws Exception {
        BasicSingleton singleton = BasicSingleton.getInstance();
        singleton.setCounter(10);

        String filename = "singleton.bin";
        saveToFile(singleton,filename);
        singleton.setCounter(11);

        BasicSingleton basicSingleton = readFromFile(filename);

        System.out.println( singleton == basicSingleton);
        System.out.println( singleton.getCounter());
        System.out.println( basicSingleton.getCounter() );
    }

    static void saveToFile(BasicSingleton singleton, String filename) throws Exception {
        try(FileOutputStream outputStream = new FileOutputStream(filename);
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream)) {
            objectOutputStream.writeObject(singleton);
        }
    }

    static BasicSingleton readFromFile(String filename) throws Exception {
        try (FileInputStream inputStream = new FileInputStream(filename);
             ObjectInputStream objectInputStream = new ObjectInputStream(inputStream)) {
            return (BasicSingleton) objectInputStream.readObject();
        }
    }
}
