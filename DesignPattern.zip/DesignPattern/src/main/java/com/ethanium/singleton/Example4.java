package com.ethanium.singleton;

// monostate
public class Example4 {

    public static void main(String[] args) {

        Person john = new Person();
        john.setAccountID("001");
        john.setName("JOHN");
        john.setBalance(100d);

        Person peter = new Person();
        System.out.println( peter );

        Person james = new Person();
        System.out.println( james );

    }
}
