package com.ethanium.singleton;

public class Person {

    private static String accountID;
    private static String name;
    private static Double balance;

    public String getAccountID() {
        return accountID;
    }

    public void setAccountID(String accountID) {
        Person.accountID = accountID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        Person.name = name;
    }

    public Double getBalance() {
        return balance;
    }

    public void setBalance(Double balance) {
        Person.balance = balance;
    }

    @Override
    public String toString() {
        return new StringBuilder("AccountID: "+accountID)
                .append("\nName: "+name)
                .append("\nBalance: "+balance).toString();
    }
}
