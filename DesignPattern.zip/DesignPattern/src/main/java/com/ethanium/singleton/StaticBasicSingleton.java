package com.ethanium.singleton;

public class StaticBasicSingleton {

    private StaticBasicSingleton() {
    }

    private static StaticBasicSingleton INSTANCE;;

    static {
        try {
            INSTANCE = new StaticBasicSingleton();
        } catch (Exception e) {
            System.err.println("failed to create singleton object");
        }
    }
    public static StaticBasicSingleton getInstance() {
        return INSTANCE;
    }

}
