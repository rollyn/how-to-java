package com.ethanium.state;

public enum Events {
  CALL_DIALED,
  HUNG_UP,
  CALL_CONNECTED,
  PLACED_ON_HOLD,
  TAKEN_OFF_HOLD,
  LEFT_MESSAGE,
  STOP_USING_PHONE
}