package com.ethanium.strategy;

import java.util.List;

public class Example {

    public static void main(String[] args) {

        TextProcessor<MarkdownListStrategy> tp = new TextProcessor<>(
                MarkdownListStrategy::new);
        tp.appendList(List.of("John", "James", "Peter"));
        System.out.println(tp);

        TextProcessor<HtmlListStrategy> tp2 = new TextProcessor<>(HtmlListStrategy::new);
        tp2.appendList(List.of("Inheritance", "Encapsulation", "Polymorphism"));
        System.out.println(tp2);
    }
}
