package com.ethanium.visitor;

public abstract class Expression {

  public abstract void accept(ExpressionVisitor visitor);
}
