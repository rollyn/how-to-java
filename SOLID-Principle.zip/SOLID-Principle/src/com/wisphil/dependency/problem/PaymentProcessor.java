package com.wisphil.dependency.problem;

public class PaymentProcessor {

    public void pay(String productId) {
        SqlProductRepo repo = new SqlProductRepo();
        Product product = repo.getById(productId);
        this.processPayment(product);
    }

    private void processPayment(Product product) {
    }
}
