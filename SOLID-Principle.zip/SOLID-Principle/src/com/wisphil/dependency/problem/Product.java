package com.wisphil.dependency.problem;

public class Product {
}
