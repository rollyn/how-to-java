package com.wisphil.dependency.problem;

public class SqlProductRepo {

    public Product getById(String id) {
        return new Product();
    }

}
