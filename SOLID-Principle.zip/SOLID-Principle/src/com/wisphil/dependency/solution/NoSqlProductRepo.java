package com.wisphil.dependency.solution;

import com.wisphil.dependency.problem.Product;

public class NoSqlProductRepo implements ProductRepo {
    @Override
    public Product getById(String id) {
        return null;
    }
}
