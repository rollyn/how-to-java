package com.wisphil.dependency.solution;

import com.wisphil.dependency.problem.Product;

public class PaymentProcessor {

    public void pay(String productId) {
        ProductRepo repo = ProductRepoFactory.create("sql");
        Product product = repo.getById(productId);
        this.processPayment(product);
    }

    private void processPayment(Product product) {
    }

}
