package com.wisphil.dependency.solution;

import com.wisphil.dependency.problem.Product;

public interface ProductRepo {

    Product getById(String id);
}
