package com.wisphil.dependency.solution;

import com.wisphil.dependency.problem.Product;

public class ProductRepoFactory {

    static ProductRepo create(String type) {
        if (type.equals("sql")) {
            return new SqlProductRepo();
        }
        return new NoSqlProductRepo();
    }
}
