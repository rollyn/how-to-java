package com.wisphil.dependency.solution.di;

import com.wisphil.dependency.problem.Product;
import com.wisphil.dependency.solution.ProductRepo;

public class PaymentProcessor {

    private ProductRepo repo;

    public PaymentProcessor(ProductRepo repo) {
        this.repo = repo;
    }


    public void pay(String productId) {
        Product product = repo.getById(productId);
        this.processPayment(product);
    }

    private void processPayment(Product product) {
    }
}
