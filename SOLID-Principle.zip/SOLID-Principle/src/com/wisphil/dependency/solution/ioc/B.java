package com.wisphil.dependency.solution.ioc;

public class B {
}
