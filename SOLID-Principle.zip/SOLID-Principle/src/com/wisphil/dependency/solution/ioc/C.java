package com.wisphil.dependency.solution.ioc;

public class C {

    public C(A a, B b) {
    }
}
