package com.wisphil.dependency.solution.ioc;

import java.lang.annotation.*;

@Documented
@Inherited
@Retention(RetentionPolicy.RUNTIME)
public @interface Configuration {
}