package com.wisphil.dependency.solution.ioc;

@Configuration
public class DependencyConfig {

    @Bean
    public A a() {
        return new A();
    }

    @Bean
    public B b() {
        return new B();
    }

    @Bean
    public C c() {
        return new C(a(),b());
    }

}
