package com.wisphil.intf.segregation.begin;

import java.math.BigDecimal;

public interface Account {

    void deposit(BigDecimal amount);
    BigDecimal withdraw(BigDecimal amount);
    Account findAccount(String accountID);
    String saveAccount(Account account);
}