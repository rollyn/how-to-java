package com.wisphil.intf.segregation.end;

import java.math.BigDecimal;

public interface Account {

    void deposit(BigDecimal amount);
    BigDecimal withdraw(BigDecimal amount);
    Account findAccount(String accountID);
    String saveAccount(Account account);

}