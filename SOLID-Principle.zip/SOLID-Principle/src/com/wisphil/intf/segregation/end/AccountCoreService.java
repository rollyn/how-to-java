package com.wisphil.intf.segregation.end;

import java.math.BigDecimal;

public interface AccountCoreService {

    void deposit(BigDecimal amount);
    BigDecimal withdraw(BigDecimal amount);

}
