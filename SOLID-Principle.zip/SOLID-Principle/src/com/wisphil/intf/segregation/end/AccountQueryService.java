package com.wisphil.intf.segregation.end;

import com.wisphil.intf.segregation.begin.Account;

public interface AccountQueryService {

    Account findAccount(String accountID);
}
