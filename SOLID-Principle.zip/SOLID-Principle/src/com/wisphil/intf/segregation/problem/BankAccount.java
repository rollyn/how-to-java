package com.wisphil.intf.segregation.problem;

public class BankAccount implements Account {
    @Override
    public double getBalance() {
        return 0;
    }

    @Override
    public void processLocalPayment(double amount) {

    }

    @Override
    public void processInternationalPayment(double amount) {

    }
}
