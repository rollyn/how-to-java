package com.wisphil.intf.segregation.problem;

public class Exampla {

    public static void main(String[] args) {
//        Account account = new BankAccount();
//        account.processLocalPayment();
//        account.processInternationalPayment();
//
//        Account account1 = new SchoolAccount();
//        account1.processLocalPayment();
//        account1.processInternationalPayment();
    }
}
