package com.wisphil.intf.segregation.problem;

public class SchoolAccount implements Account {
    @Override
    public double getBalance() {
        return 0;
    }

    @Override
    public void processLocalPayment(double amount) {

    }

    @Override
    public void processInternationalPayment(double amount) {
        // this is not required method for school account
        throw new RuntimeException("International payment is not implemented");
    }


}
