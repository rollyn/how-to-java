package com.wisphil.intf.segregation.solution;

public class BankAccount implements BaseAccount, LocalPayment, InternationalPayment {
    @Override
    public double getBalance() {
        return 0;
    }

    @Override
    public void processInternationalPayment(double amount) {

    }

    @Override
    public void processLocalPayment(double amount) {

    }
}
