package com.wisphil.intf.segregation.solution;

public interface BaseAccount {
    double getBalance();
}
