package com.wisphil.intf.segregation.solution;

public interface InternationalPayment {

    void processInternationalPayment(double amount);
}
