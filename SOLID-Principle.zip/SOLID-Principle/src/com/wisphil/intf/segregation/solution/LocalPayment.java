package com.wisphil.intf.segregation.solution;

public interface LocalPayment {

    void processLocalPayment(double amount);
}
