package com.wisphil.intf.segregation.solution;

public class SchoolAccount implements BaseAccount, LocalPayment {
    @Override
    public double getBalance() {
        return 0;
    }

    @Override
    public void processLocalPayment(double amount) {

    }
}
