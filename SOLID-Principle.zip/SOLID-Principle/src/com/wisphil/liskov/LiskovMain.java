package com.wisphil.liskov;

public class LiskovMain {

    public static void main(String[] args) {

        Shape rectangle = new Rectangle();
        rectangle.setWidth(10);
        rectangle.setHeight(20);

        System.out.println(  rectangle.calculateArea() );

        Shape square = new Square();
        square.setWidth(10);
        square.setHeight(20);

        System.out.println(  square.calculateArea() );
    }
}
