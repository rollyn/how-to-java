package com.wisphil.liskov;

public class Rectangle extends Shape {

}
