package com.wisphil.liskov;

public class Square extends Shape {
    @Override
    public void setWidth(int width) {
        super.setWidth(width);
    }

    @Override
    public void setHeight(int height) {
        if (height != super.getWidth()) {
            throw new RuntimeException("Height should be the same with Width");
        }
    }
}
