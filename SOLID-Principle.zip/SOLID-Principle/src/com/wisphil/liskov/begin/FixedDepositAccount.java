package com.wisphil.liskov.begin;

import java.math.BigDecimal;

public class FixedDepositAccount extends Account {
    @Override
    protected void deposit(BigDecimal amount) {
        //deposit
    }

    @Override
    protected void withdraw(BigDecimal amount) {
        throw new UnsupportedOperationException("Cannot withdraw on a fixed account");
    }
}
