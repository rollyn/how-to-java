package com.wisphil.liskov.begin;

import java.math.BigDecimal;

public class LiskovMain {

    public static void main(String[] args) {

        Account savingsAccount = new SavingsAccount();
        savingsAccount.withdraw(new BigDecimal(100));

        Account fixedDepositAccount = new FixedDepositAccount();
        fixedDepositAccount.withdraw(new BigDecimal(1000));


    }
}
