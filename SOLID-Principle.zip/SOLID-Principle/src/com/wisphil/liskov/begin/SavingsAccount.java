package com.wisphil.liskov.begin;

import java.math.BigDecimal;

public class SavingsAccount extends Account {
    @Override
    protected void deposit(BigDecimal amount) {
        //deposit
    }

    @Override
    protected void withdraw(BigDecimal amount) {
        //withdrawal
    }
}
