package com.wisphil.liskov.end;

import java.math.BigDecimal;

public interface Account {

    void deposit(BigDecimal amount);
}