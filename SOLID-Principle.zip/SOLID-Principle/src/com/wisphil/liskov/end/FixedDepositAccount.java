package com.wisphil.liskov.end;

import java.math.BigDecimal;

public class FixedDepositAccount implements Account {

    @Override
    public void deposit(BigDecimal amount) {
        //deposit
    }
}
