package com.wisphil.liskov.end;

import java.math.BigDecimal;

public class LiskovMain {

    public static void main(String[] args) {

        WithdrawableAccount savingsAccount = new SavingsAccount();
//        savingsAccount.deposit(new BigDecimal(200));
        savingsAccount.withdraw(new BigDecimal(100));

        Account fixedDepositAccount = new FixedDepositAccount();
//        fixedDepositAccount.withdraw(new BigDecimal(1000));
        fixedDepositAccount.deposit(new BigDecimal(10));

    }
}
