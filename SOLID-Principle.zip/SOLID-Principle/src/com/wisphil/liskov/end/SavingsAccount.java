package com.wisphil.liskov.end;

import java.math.BigDecimal;

public class SavingsAccount implements Account,WithdrawableAccount {

    @Override
    public void deposit(BigDecimal amount) {

    }

    @Override
    public void withdraw(BigDecimal amount) {

    }
}
