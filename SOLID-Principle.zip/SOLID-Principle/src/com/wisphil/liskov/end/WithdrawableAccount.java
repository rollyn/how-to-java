package com.wisphil.liskov.end;

import java.math.BigDecimal;

public interface WithdrawableAccount {

    void withdraw(BigDecimal amount);
}
