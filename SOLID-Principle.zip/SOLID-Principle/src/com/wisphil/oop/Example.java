package com.wisphil.oop;

public class Example {

    public static void main(String[] args) {
        OPlayer player = new VlcPlayer();

        player.play();
        player.stop();

    }
}
