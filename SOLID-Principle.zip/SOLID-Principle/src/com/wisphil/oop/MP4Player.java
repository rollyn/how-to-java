package com.wisphil.oop;

public class MP4Player extends OPlayer  {
    @Override
    public void play() {
        System.out.println("MP4 Player");
    }
}
