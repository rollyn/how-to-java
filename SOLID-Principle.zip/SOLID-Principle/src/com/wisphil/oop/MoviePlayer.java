package com.wisphil.oop;

public class MoviePlayer implements Player {

    @Override
    public void play() {
            System.out.println("Movie Player");
    }

    @Override
    public void stop() {

    }
}
