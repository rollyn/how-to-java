package com.wisphil.oop;

public abstract class OPlayer {

    abstract void play();
    void stop() {
        System.out.println("Stop....");
    }

}
