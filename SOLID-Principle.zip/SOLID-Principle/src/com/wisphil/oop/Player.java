package com.wisphil.oop;

public interface Player {

    void play();
    void stop();

}
