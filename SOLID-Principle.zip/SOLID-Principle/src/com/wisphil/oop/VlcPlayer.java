package com.wisphil.oop;

public class VlcPlayer extends OPlayer  {
    @Override
    public void play() {

    }
}
