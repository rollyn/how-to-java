package com.wisphil.open.close.begin;

public class AccountPersistence {

    public void saveToFile(Account account) {
        // Creates a file
    }

    public void saveToDatabase(Account account) {
        // Saves the account
    }
}
