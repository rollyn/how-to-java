package com.wisphil.open.close.end;

import com.wisphil.open.close.begin.Account;

public interface AccountPersistence {

    public void save(Account account);

}
