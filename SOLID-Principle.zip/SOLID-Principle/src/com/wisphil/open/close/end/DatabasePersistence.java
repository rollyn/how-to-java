package com.wisphil.open.close.end;

import com.wisphil.open.close.begin.Account;

public class DatabasePersistence implements AccountPersistence {
    @Override
    public void save(Account account) {
        // save to database
    }
}
