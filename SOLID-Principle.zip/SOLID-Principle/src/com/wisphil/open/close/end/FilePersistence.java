package com.wisphil.open.close.end;

import com.wisphil.open.close.begin.Account;

public class FilePersistence implements AccountPersistence {
    @Override
    public void save(Account account) {
        // save to file
    }
}
