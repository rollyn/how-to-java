package com.wisphil.open.close.end;

public class Transaction {

    private DatabasePersistence db;
    private FilePersistence file;

    public Transaction(DatabasePersistence db, FilePersistence file) {
        this.db = db;
        this.file = file;
    }

}
