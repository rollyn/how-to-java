package com.wisphil.open.close.problem;

public class Contractual implements Employee {
    @Override
    public double getBalance() {
        return 0;
    }
}
