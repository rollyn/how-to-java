package com.wisphil.open.close.problem;

public interface Employee {

    double getBalance();
}
