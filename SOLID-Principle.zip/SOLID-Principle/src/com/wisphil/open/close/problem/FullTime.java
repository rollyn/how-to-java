package com.wisphil.open.close.problem;

public class FullTime implements Employee {
    @Override
    public double getBalance() {
        return 0;
    }
}
