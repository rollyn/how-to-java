package com.wisphil.open.close.problem;

public class PartTime implements Employee {
    @Override
    public double getBalance() {
        return 0;
    }
}
