package com.wisphil.open.close.problem;

public class TaxCalculator {

    private double TAX_PERCENTAGE = 15;

    public double calculate(Employee employee) {
        return employee.getBalance() * (TAX_PERCENTAGE / 100);
    }
}
