package com.wisphil.open.close.solution;

import com.wisphil.open.close.problem.Employee;

public class ContractualTaxCalculator implements TaxCalculator {

    @Override
    public double calculate(Employee employee) {
        return 0;
    }
}
