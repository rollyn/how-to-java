package com.wisphil.open.close.solution;

import com.wisphil.open.close.problem.Employee;

public class FullTimeTaxCalculator implements TaxCalculator {

    private double TAX_PERCENTAGE = 15;

    public double calculate(Employee employee) {
        System.out.println("FullTimeTaxCalculator");
        return employee.getBalance() * (TAX_PERCENTAGE / 100);
    }

}
