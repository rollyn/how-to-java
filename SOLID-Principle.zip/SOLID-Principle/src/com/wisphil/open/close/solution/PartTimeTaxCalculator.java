package com.wisphil.open.close.solution;

import com.wisphil.open.close.problem.Employee;

public class PartTimeTaxCalculator implements TaxCalculator {

    private double TAX_PERCENTAGE = 10;

    public double calculate(Employee employee) {
        System.out.println("PartTimeTaxCalculator");
        return employee.getBalance() * (TAX_PERCENTAGE / 100);
    }
}
