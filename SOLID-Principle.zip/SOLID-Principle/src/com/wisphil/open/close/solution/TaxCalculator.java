package com.wisphil.open.close.solution;

import com.wisphil.open.close.problem.Employee;

public interface TaxCalculator {

    double calculate(Employee employee);
}
