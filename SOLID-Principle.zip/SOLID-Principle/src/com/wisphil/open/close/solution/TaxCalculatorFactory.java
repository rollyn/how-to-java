package com.wisphil.open.close.solution;

import com.wisphil.open.close.problem.Employee;
import com.wisphil.open.close.problem.FullTime;
import com.wisphil.open.close.problem.PartTime;

public class TaxCalculatorFactory {

    public static TaxCalculator build(Employee employee) {
        if (employee instanceof PartTime) {
            return new PartTimeTaxCalculator();
        } else if (employee instanceof FullTime) {
            return new FullTimeTaxCalculator();
        } else if (employee instanceof FullTime) {
            return new FullTimeTaxCalculator();
        }
        return null;
    }
}
