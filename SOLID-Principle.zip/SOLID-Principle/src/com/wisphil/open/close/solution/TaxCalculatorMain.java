package com.wisphil.open.close.solution;

import com.wisphil.open.close.problem.Contractual;
import com.wisphil.open.close.problem.Employee;
import com.wisphil.open.close.problem.FullTime;
import com.wisphil.open.close.problem.PartTime;

public class TaxCalculatorMain {

    public static void main(String[] args) {

        Employee employee = new Contractual();

        TaxCalculator factory = TaxCalculatorFactory.build(employee);
        factory.calculate(employee);
    }
}
