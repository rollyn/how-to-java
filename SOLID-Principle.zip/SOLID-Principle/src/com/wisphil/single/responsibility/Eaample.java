package com.wisphil.single.responsibility;

import com.wisphil.single.responsibility.begin.Account;

public class Eaample {

    public static void main(String[] args) {

        Account account = new Account();
       // account.accountID = "0001";
        account.setAccountID(null);



    }
}
