package com.wisphil.single.responsibility;

import java.time.LocalDateTime;

public class GodClass {

    byte[] serialize(Object e) {
        return null;
    }

    String toFriendlyDate(LocalDateTime e) {
        return null;
    }

    int roundDoubleToInt(Double e) {
        return 1;
    }

}
