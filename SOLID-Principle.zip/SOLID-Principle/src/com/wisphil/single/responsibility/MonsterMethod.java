package com.wisphil.single.responsibility;

import java.util.Optional;

public class MonsterMethod {

    //Monster method
    Optional<Report> generate(String type) {

        if (type.equals("HR")) {
            // generate HR report
        } else if (type.equals("FINANCE")) {
            // generate finance report
        } else if (type.equals("ACCOUNTING")) {

        }

        return Optional.empty();
    }

}
