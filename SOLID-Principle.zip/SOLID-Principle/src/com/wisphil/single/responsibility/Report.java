package com.wisphil.single.responsibility;

public class Report {
}
