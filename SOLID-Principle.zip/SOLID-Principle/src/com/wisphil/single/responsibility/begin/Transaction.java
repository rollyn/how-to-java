package com.wisphil.single.responsibility.begin;

public class Transaction {

    private Account account;
    private String operation;

    public void withdraw(Double amount) {
        double balance = this.account.getBalance() - amount;
        this.account.setBalance( balance );
    }

    public void printTransaction() {
        System.out.printf("AccountID: %s",account.getAccountID());
        System.out.printf("Balance: %f",account.getBalance());
        System.out.printf("AccountID: %s",account.getAccountID());
        System.out.printf("Balance: %f",account.getBalance());
        System.out.printf("AccountID: %s",account.getAccountID());
        System.out.printf("Balance: %f",account.getBalance());
        System.out.printf("AccountID: %s",account.getAccountID());
        System.out.printf("Balance: %f",account.getBalance());
        System.out.printf("AccountID: %s",account.getAccountID());
        System.out.printf("Balance: %f",account.getBalance());
        System.out.printf("AccountID: %s",account.getAccountID());
        System.out.printf("Balance: %f",account.getBalance());
        print();

    }

    public void print() {
        System.out.printf("AccountID: %s",account.getAccountID());
        System.out.printf("Balance: %f",account.getBalance());
        System.out.printf("AccountID: %s",account.getAccountID());
        System.out.printf("Balance: %f",account.getBalance());
        System.out.printf("AccountID: %s",account.getAccountID());
        System.out.printf("Balance: %f",account.getBalance());System.out.printf("AccountID: %s",account.getAccountID());
        System.out.printf("Balance: %f",account.getBalance());
        System.out.printf("AccountID: %s",account.getAccountID());
        System.out.printf("Balance: %f",account.getBalance());System.out.printf("AccountID: %s",account.getAccountID());
        System.out.printf("Balance: %f",account.getBalance());
        System.out.printf("AccountID: %s",account.getAccountID());
        System.out.printf("Balance: %f",account.getBalance());
        System.out.printf("AccountID: %s",account.getAccountID());
        System.out.printf("Balance: %f",account.getBalance());
        System.out.printf("AccountID: %s",account.getAccountID());
        System.out.printf("Balance: %f",account.getBalance());System.out.printf("AccountID: %s",account.getAccountID());
        System.out.printf("Balance: %f",account.getBalance());System.out.printf("AccountID: %s",account.getAccountID());
        System.out.printf("Balance: %f",account.getBalance());
    }


    public void saveToFile(Account account) {
        // save to file
    }
}
