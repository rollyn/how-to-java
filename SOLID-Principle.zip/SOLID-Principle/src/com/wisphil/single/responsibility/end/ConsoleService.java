package com.wisphil.single.responsibility.end;

public class ConsoleService implements Printer {

    @Override
    public void print(Account account) {
        System.out.printf("AccountID: %s",account.getAccountID());
        System.out.printf("Balance: %f",account.getBalance());
    }
}
