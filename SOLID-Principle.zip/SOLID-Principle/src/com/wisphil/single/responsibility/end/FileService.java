package com.wisphil.single.responsibility.end;

public class FileService implements Printer {

    @Override
    public void print(Account account) {
        // save to file
    }
}
