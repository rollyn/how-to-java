package com.wisphil.single.responsibility.end;

public interface Printer {

    void print(Account account);
}
