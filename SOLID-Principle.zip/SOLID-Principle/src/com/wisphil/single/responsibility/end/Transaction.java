package com.wisphil.single.responsibility.end;

import com.wisphil.single.responsibility.begin.Account;

public class Transaction {

    private Account account;
    private String operation;

    public void withdraw(Double amount) {
        double balance = this.account.getBalance() - amount;
        this.account.setBalance( balance );
    }

}
