package com.ethanium;

public class PasswordValidator {

    public boolean checkLength(String password) {
//        if (password.length() >= 8) {
//            return true;
//        }
//        return false;
        return password.length() >= 8;
    }

    public boolean checkValidPassword(String password) {
        if (password.matches(".*\\d.*")) {
            return true;
        }
        return false;
    }
}
