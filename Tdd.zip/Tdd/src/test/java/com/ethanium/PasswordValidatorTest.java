package com.ethanium;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class PasswordValidatorTest {

    @Test
    public void shouldHaveValidPasswordLength() {
        PasswordValidator validator = new PasswordValidator();
        assertTrue(validator.checkLength("PASSWORD"));
    }

    @Test
    public void shouldHaveAtLeastOneNumericCharacter() {
        PasswordValidator validator = new PasswordValidator();
        assertTrue(validator.checkValidPassword("2PASSWORD"));
    }
}
